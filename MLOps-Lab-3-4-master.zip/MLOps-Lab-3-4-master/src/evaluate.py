"""
Model evaluation utilities.
"""

import os

import matplotlib.pyplot as plt

from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    confusion_matrix,
    classification_report,
    ConfusionMatrixDisplay
)


def evaluate_model(model, X_test, y_test, figures_dir="reports/figures"):
    """
    Evaluate a trained classification model.

    Returns:
        metrics: Dictionary containing evaluation metrics.
        cm: Confusion matrix.
        report: Classification report.
        predictions: Model predictions.
    """

    # Generate predictions
    y_pred = model.predict(X_test)

    # Calculate metrics
    metrics = {
        "accuracy": accuracy_score(y_test, y_pred),
        "precision": precision_score(y_test, y_pred),
        "recall": recall_score(y_test, y_pred),
        "f1": f1_score(y_test, y_pred)
    }

    # Confusion matrix
    cm = confusion_matrix(y_test, y_pred)

    # Classification report
    report = classification_report(y_test, y_pred)

    # Create figures directory
    os.makedirs(figures_dir, exist_ok=True)

    # Create confusion matrix plot
    fig, ax = plt.subplots(figsize=(6, 5))

    ConfusionMatrixDisplay(
        confusion_matrix=cm
    ).plot(ax=ax)

    ax.set_title("Random Forest Confusion Matrix")

    plt.tight_layout()

    confusion_matrix_path = os.path.join(
        figures_dir,
        "confusion_matrix.png"
    )

    plt.savefig(confusion_matrix_path, dpi=300)

    plt.close(fig)

    return metrics, cm, report, confusion_matrix_path