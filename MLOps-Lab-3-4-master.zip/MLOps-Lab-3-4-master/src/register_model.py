"""
Register the selected MLflow model and assign the champion alias.
"""

import mlflow
from mlflow import MlflowClient


# ============================================================
# Configuration
# ============================================================

RUN_ID = "5db8befdb4794cc1b3fb03fcf703a20e"

MODEL_ARTIFACT_NAME = "random_forest_model"

REGISTERED_MODEL_NAME = "BreastCancerRandomForest"


# ============================================================
# MLflow client
# ============================================================

client = MlflowClient()


# ============================================================
# Model URI
# ============================================================

model_uri = (
    f"runs:/{RUN_ID}/{MODEL_ARTIFACT_NAME}"
)

print("=" * 60)
print("MODEL REGISTRATION")
print("=" * 60)

print(f"\nRun ID:")
print(RUN_ID)

print(f"\nModel URI:")
print(model_uri)

print(f"\nRegistered model name:")
print(REGISTERED_MODEL_NAME)


# ============================================================
# Register model
# ============================================================

print("\nRegistering model...")

model_version = mlflow.register_model(
    model_uri=model_uri,
    name=REGISTERED_MODEL_NAME
)

print("\nModel registered successfully.")

print(f"Model name : {model_version.name}")
print(f"Version    : {model_version.version}")


# ============================================================
# Assign champion alias
# ============================================================

print("\nAssigning 'champion' alias...")

client.set_registered_model_alias(
    name=REGISTERED_MODEL_NAME,
    alias="champion",
    version=model_version.version
)

print("Champion alias assigned successfully.")


# ============================================================
# Verify
# ============================================================

registered_model = client.get_registered_model(
    REGISTERED_MODEL_NAME
)

print("\nRegistered Model")
print("-" * 40)

print(f"Name    : {registered_model.name}")
print(f"Aliases : {registered_model.aliases}")

print("\nModel registration completed successfully.")