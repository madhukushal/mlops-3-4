﻿"""
Data loading and preprocessing utilities.
Loads the dataset tracked by DVC.
"""

from pathlib import Path

import pandas as pd
from sklearn.model_selection import train_test_split


DATASET_PATH = Path("data") / "dataset.csv"


def load_data(dataset_path=DATASET_PATH):
    """
    Load the DVC-tracked Breast Cancer dataset.

    Returns:
        X: Feature DataFrame with feature names
        y: Target Series
    """
    dataset_path = Path(dataset_path)

    if not dataset_path.exists():
        raise FileNotFoundError(
            f"Dataset not found: {dataset_path.resolve()}"
        )

    data = pd.read_csv(dataset_path)

    if "target" not in data.columns:
        raise ValueError("Dataset must contain a 'target' column.")

    X = data.drop(columns=["target"])
    y = data["target"]

    if X.empty or y.empty:
        raise ValueError("Dataset contains no usable rows or features.")

    return X, y


def split_data(X, y, test_size=0.2, random_state=42):
    """
    Split the feature matrix and target into training and testing sets.
    """
    return train_test_split(
        X,
        y,
        test_size=test_size,
        random_state=random_state
    )
