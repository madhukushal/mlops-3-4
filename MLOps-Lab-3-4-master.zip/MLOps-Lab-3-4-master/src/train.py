﻿"""
Reproducible ML training pipeline with MLflow tracking,
DVC dataset metadata, Git provenance, and model signatures.
"""

import argparse
import os
import subprocess
from pathlib import Path

import joblib
import mlflow
import mlflow.sklearn
import yaml
from mlflow.models import infer_signature
from sklearn.ensemble import RandomForestClassifier

from data_preprocessing import load_data, split_data
from evaluate import evaluate_model


PROJECT_ROOT = Path(__file__).resolve().parents[1]
os.chdir(PROJECT_ROOT)


def load_config(config_path):
    with open(config_path, "r", encoding="utf-8-sig") as file:
        return yaml.safe_load(file)


def get_git_commit():
    try:
        return subprocess.check_output(
            ["git", "rev-parse", "HEAD"],
            cwd=PROJECT_ROOT,
            text=True,
            stderr=subprocess.DEVNULL,
        ).strip()
    except (subprocess.CalledProcessError, FileNotFoundError):
        return "unknown"


def get_dvc_dataset_hash():
    metadata_path = PROJECT_ROOT / "data" / "dataset.csv.dvc"

    if not metadata_path.exists():
        return "unknown"

    with open(metadata_path, "r", encoding="utf-8-sig") as file:
        metadata = yaml.safe_load(file)

    outputs = metadata.get("outs", [])
    return outputs[0].get("md5", "unknown") if outputs else "unknown"


def main(config_path):
    config_path = Path(config_path)
    if not config_path.is_absolute():
        config_path = PROJECT_ROOT / config_path

    config = load_config(config_path)
    model_config = config["model"]
    training_config = config["training"]

    git_commit = get_git_commit()
    dataset_hash = get_dvc_dataset_hash()
    dataset_path = PROJECT_ROOT / "data" / "dataset.csv"

    print("=" * 60)
    print("REPRODUCIBLE ML TRAINING WITH MLFLOW")
    print("=" * 60)
    print("Configuration:", config_path.name)
    print("Git commit:", git_commit)
    print("DVC dataset hash:", dataset_hash)

    mlflow.set_experiment("Breast Cancer Random Forest")

    with mlflow.start_run(run_name=config_path.stem) as run:
        X, y = load_data(dataset_path)

        X_train, X_test, y_train, y_test = split_data(
            X,
            y,
            test_size=training_config["test_size"],
            random_state=training_config["random_state"],
        )

        model = RandomForestClassifier(
            n_estimators=model_config["n_estimators"],
            max_depth=model_config["max_depth"],
            min_samples_split=model_config["min_samples_split"],
            random_state=training_config["random_state"],
        )

        model.fit(X_train, y_train)

        metrics, cm, report, confusion_matrix_path = evaluate_model(
            model, X_test, y_test
        )

        mlflow.log_params({
            "model_type": model_config["type"],
            "n_estimators": model_config["n_estimators"],
            "max_depth": (
                str(model_config["max_depth"])
                if model_config["max_depth"] is not None
                else "None"
            ),
            "min_samples_split": model_config["min_samples_split"],
            "test_size": training_config["test_size"],
            "random_state": training_config["random_state"],
            "config_file": config_path.name,
            "dataset_rows": len(X),
            "dataset_features": X.shape[1],
        })

        mlflow.set_tags({
            "git_commit": git_commit,
            "dvc_dataset_hash": dataset_hash,
            "dataset_path": "data/dataset.csv",
            "model_variant": config_path.stem,
            "lifecycle_state": "candidate",
        })

        mlflow.log_metrics({
            key: float(value) for key, value in metrics.items()
        })

        reports_dir = PROJECT_ROOT / "reports"
        reports_dir.mkdir(exist_ok=True)

        report_path = reports_dir / f"classification_report_{config_path.stem}.txt"
        with open(report_path, "w", encoding="utf-8") as file:
            file.write(f"Configuration: {config_path.name}\n")
            file.write(f"Git commit: {git_commit}\n")
            file.write(f"DVC dataset hash: {dataset_hash}\n\n")
            file.write("Metrics:\n")
            for name, value in metrics.items():
                file.write(f"{name}: {value:.6f}\n")
            file.write("\nDetailed classification report:\n")
            file.write(report)

        mlflow.log_artifact(str(confusion_matrix_path))
        mlflow.log_artifact(str(report_path))

        signature = infer_signature(
            X_train,
            model.predict(X_train),
        )

        input_example = X_train.head(5)

        mlflow.sklearn.log_model(
            sk_model=model,
            artifact_path="random_forest_model",
            signature=signature,
            input_example=input_example,
        )

        models_dir = PROJECT_ROOT / "models"
        models_dir.mkdir(exist_ok=True)
        joblib.dump(model, models_dir / f"{config_path.stem}_model.joblib")

        print("\nEvaluation results:")
        for name, value in metrics.items():
            print(f"{name}: {value:.4f}")

        print("\nRun ID:", run.info.run_id)
        print("Git commit:", git_commit)
        print("DVC dataset hash:", dataset_hash)
        print("Model signature and input example logged.")
        print("Artifacts logged:", confusion_matrix_path, report_path)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--config",
        default="configs/config.yaml",
        help="Path to the YAML configuration file",
    )
    args = parser.parse_args()
    main(args.config)
