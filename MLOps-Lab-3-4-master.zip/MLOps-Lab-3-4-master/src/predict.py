"""
Load the champion model from MLflow Model Registry
and perform inference.
"""

import mlflow
import numpy as np
from sklearn.datasets import load_breast_cancer


# ============================================================
# MLflow Configuration
# ============================================================

MLFLOW_TRACKING_URI = "http://127.0.0.1:5000"

MODEL_NAME = "BreastCancerRandomForest"
MODEL_ALIAS = "champion"

MODEL_URI = f"models:/{MODEL_NAME}@{MODEL_ALIAS}"


# ============================================================
# Main
# ============================================================

def main():

    print("=" * 60)
    print("MODEL INFERENCE USING MLflow MODEL REGISTRY")
    print("=" * 60)

    # --------------------------------------------------------
    # Connect to MLflow
    # --------------------------------------------------------

    print("\nConnecting to MLflow...")
    mlflow.set_tracking_uri(MLFLOW_TRACKING_URI)

    print(f"Tracking URI: {MLFLOW_TRACKING_URI}")

    # --------------------------------------------------------
    # Load dataset
    # --------------------------------------------------------

    print("\nLoading breast cancer dataset...")

    data = load_breast_cancer()

    X = data.data
    y = data.target

    print(f"Dataset shape: {X.shape}")

    # --------------------------------------------------------
    # Load champion model
    # --------------------------------------------------------

    print("\nLoading champion model...")
    print(f"Model URI: {MODEL_URI}")

    model = mlflow.sklearn.load_model(MODEL_URI)

    print("Champion model loaded successfully.")

    # --------------------------------------------------------
    # Select samples for inference
    # --------------------------------------------------------

    X_sample = X[:10]
    y_actual = y[:10]

    # --------------------------------------------------------
    # Generate predictions
    # --------------------------------------------------------

    print("\nGenerating predictions...")

    predictions = model.predict(X_sample)

    # --------------------------------------------------------
    # Display predictions
    # --------------------------------------------------------

    print("\nInference Results")
    print("-" * 60)

    for i, (actual, predicted) in enumerate(
        zip(y_actual, predictions)
    ):
        print(
            f"Sample {i + 1:02d} | "
            f"Actual: {actual} | "
            f"Predicted: {predicted}"
        )

    # --------------------------------------------------------
    # Calculate sample accuracy
    # --------------------------------------------------------

    accuracy = np.mean(predictions == y_actual)

    print("\nSample Accuracy:")
    print(f"{accuracy:.4f}")

    print("\nInference completed successfully.")


# ============================================================
# Entry Point
# ============================================================

if __name__ == "__main__":
    main()