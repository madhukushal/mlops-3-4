import mlflow


RUN_ID = "5db8befdb4794cc1b3fb03fcf703a20e"

mlflow.set_tracking_uri("http://127.0.0.1:5000")

client = mlflow.MlflowClient()

run = client.get_run(RUN_ID)

print("=" * 60)
print("MLFLOW RUN REPRODUCTION INFORMATION")
print("=" * 60)

print("\nRun ID:")
print(run.info.run_id)

print("\nRun Name:")
print(run.info.run_name)

print("\nParameters")
print("-" * 40)

for key, value in run.data.params.items():
    print(f"{key}: {value}")

print("\nMetrics")
print("-" * 40)

for key, value in run.data.metrics.items():
    print(f"{key}: {value}")

print("\nRun information retrieved successfully.")